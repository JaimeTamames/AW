//Jaime Tamames y Ruben Barrado

module.exports = {
    /* Configuración de los datos de acceso a la BD */
    mysqlConfig: {
        dbName: "BDPractica1",
        dbHost: "localhost",
        dbUser: "root",
        dbPassword: ""
		/* Puerto de escucha */
		port: 3000
    },
    
    
};

